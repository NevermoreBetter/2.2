package com.company;

public enum State {Success,Error,Q1,Q2,Q3,Q4,Initial}
