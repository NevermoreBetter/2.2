package com.company;

public enum Event {Slash,LowerLetter,UpperLetter,Any,EOS}
